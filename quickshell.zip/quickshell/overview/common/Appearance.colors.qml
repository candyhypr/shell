pragma Singleton
import QtQuick

QtObject {
    property bool darkmode: true
    property color m3primary: "#d6b7ee"
    property color m3onPrimary: "#1f112c"
    property color m3primaryContainer: "#654f7a"
    property color m3onPrimaryContainer: "#ffffff"
    property color m3secondary: "#ccbcd4"
    property color m3onSecondary: "#18131d"
    property color m3onSecondaryTransparent: Qt.rgba(
        Qt.color("#18131d").r,
        Qt.color("#18131d").g,
        Qt.color("#18131d").b,
        0.4)
    property color m3secondaryContainer: "#5d5264"
    property color m3onSecondaryContainer: "#ffffff"
    property color m3background: "#18131d"
    property color m3onBackground: "#e4dee2"
    property color m3surface: "#000000"
    property color m3surfaceContainerLow: "#060607"
    property color m3surfaceContainer: "#0e0d0f"
    property color m3surfaceContainerHigh: "#19181a"
    property color m3surfaceContainerHighest: "#262426"
    property color m3onSurface: "#e9e2e7"
    property color m3surfaceVariant: "#38343a"
    property color m3onSurfaceVariant: "#c7bec8"
    property color m3inversePrimary: "#56416a"
    property color m3inverseSurface: "#e4dee2"
    property color m3inverseOnSurface: "#1d1b1d"
    property color m3outline: "#918a93"
    property color m3outlineVariant: "#59535c"
    property color m3shadow: "#000000"
}
