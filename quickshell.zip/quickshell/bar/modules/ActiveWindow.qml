import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import ".."

// Active window — icon + truncated title of the focused window.
// Icon resolution mirrors the working overview/OverviewWindow.qml pattern:
//   1. DesktopEntries.heuristicLookup(class) → icon name from .desktop file
//   2. Quickshell.iconPath(name) → theme icon path (fast, covers most apps)
//   3. tray-icon-resolve.py <name> → full XDG fallback for edge cases
Item {
    id: root
    Layout.alignment: Qt.AlignVCenter
    implicitWidth:  Math.max(Config.activeWindowMinWidth,
                             row.implicitWidth + Config.modPadH * 2)
    implicitHeight: Config.moduleHeight
    visible: true

    readonly property string winTitle:    HyprlandFocusedClient.title        ?? ""
    readonly property string winClass:    HyprlandFocusedClient.class        ?? ""
    readonly property string initialClass:HyprlandFocusedClient.initialClass ?? ""
    readonly property string winAddress:  HyprlandFocusedClient.address      ?? ""
    readonly property bool   _noWindow:   winAddress === ""

    // ── Icon resolution (mirrors OverviewWindow.qml) ─────────────────────
    readonly property var _entry: DesktopEntries.heuristicLookup(
        winClass !== "" ? winClass : initialClass)

    // Best icon candidate: desktop entry → class → initialClass → generic
    readonly property string iconCandidate: {
        if (_entry?.icon && _entry.icon !== "") return _entry.icon
        if (winClass      !== "") return winClass
        if (initialClass  !== "") return initialClass
        return "application-x-executable"
    }

    // Whether the candidate needs external resolution
    readonly property bool needsResolve: !_noWindow &&
        iconCandidate !== "" &&
        !iconCandidate.startsWith("/") &&
        !iconCandidate.startsWith("file://") &&
        !iconCandidate.startsWith("image://")

    readonly property string iconLookupKey: (iconCandidate || "").trim()

    // Resolved path from tray-icon-resolve.py (fills in when Quickshell.iconPath misses)
    property string resolvedIcon: ""

    // Final source: resolved path > Quickshell.iconPath > empty
    readonly property string iconSource: {
        if (_noWindow) return ""
        if (resolvedIcon !== "") return "file://" + resolvedIcon
        if (iconCandidate.startsWith("image://") ||
            iconCandidate.startsWith("file://"))  return iconCandidate
        if (iconCandidate.startsWith("/"))        return "file://" + iconCandidate
        return Quickshell.iconPath(iconCandidate, "application-x-executable")
    }

    // Fallback resolver — argv[1] mode, same as OverviewWindow uses
    Process {
        id: iconResolverProc
        command: ["python3",
                  Quickshell.env("HOME") + "/.config/quickshell/bar/tray-icon-resolve.py",
                  root.iconLookupKey]
        running: false
        stdout: SplitParser {
            splitMarker: "\n"
            onRead: function(line) {
                const p = line.trim()
                if (p) root.resolvedIcon = p
            }
        }
    }

    function refreshResolvedIcon() {
        resolvedIcon = ""
        if (needsResolve) iconResolverProc.running = true
    }

    onIconCandidateChanged: refreshResolvedIcon()
    Component.onCompleted:  refreshResolvedIcon()

    // ── Layout ────────────────────────────────────────────────────────────
    Row {
        id: row
        anchors.centerIn: parent
        spacing: Config.iconTextGap

        Image {
            id: appIcon
            source: root.iconSource
            width: 14; height: 14
            fillMode: Image.PreserveAspectFit
            smooth: true; mipmap: true
            anchors.verticalCenter: parent.verticalCenter
            visible: !root._noWindow && source !== "" && status !== Image.Error

            // If Quickshell.iconPath returned something but it failed to load,
            // fire the resolver to get the XDG path directly
            onStatusChanged: {
                if (status === Image.Error && root.resolvedIcon === "" && root.needsResolve)
                    iconResolverProc.running = true
            }
        }

        // Placeholder glyph when no window / icon unavailable
        Text {
            visible: root._noWindow ||
                     root.iconSource === "" ||
                     appIcon.status === Image.Error
            text:           "󱑙"   // nf-md-circle_off_outline
            color:          Theme.cOnSurfVar
            font.family:    Config.fontFamily
            font.pixelSize: Config.glyphSize
            anchors.verticalCenter: parent.verticalCenter
        }

        Text {
            visible: root.winTitle !== ""
            text: root.winTitle.length > 32
                ? root.winTitle.substring(0, 31) + "…"
                : root.winTitle
            color:          Config.windowTextColor
            font.family:    Config.labelFont
            font.pixelSize: Config.labelFontSize
            anchors.verticalCenter: parent.verticalCenter
        }
    }
}
